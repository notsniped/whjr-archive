function setup() {
    canvas = createCanvas(300, 300);
    canvas.center();
}
function draw() {

}